# Godot Getaway
Following the Godot Getaway Tutorial on Udemy - Created by Canopy Games, Yann Burrett, Michael Bridges

https://www.udemy.com/course/gg-godot/

Up to Vid 48 using Godot 3.1.2

Updated to Godot 3.2 Jan 31 20

Currently on Vid 55 Win Conditions

This should be exactly the same as the course but may not be - It seems to work as it should.
